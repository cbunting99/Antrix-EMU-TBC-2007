/****************************************************************************
 *
 * General Object Type File
 * Copyright (c) 2007 Antrix Team
 *
 * This file may be distributed under the terms of the Q Public License
 * as defined by Trolltech ASA of Norway and appearing in the file
 * COPYING included in the packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

// Opcode implementation file
#include "LogonStdAfx.h"
/*
NameTableEntry g_logonOpcodeNames[] = {
	{ RSMSG_AUTH_CHALLENGE,		 "RSMSG_AUTH_CHALLENGE" },
	{ RCMSG_AUTH_RESPONSE,		  "RCMSG_AUTH_RESPONSE"  },
	{ RSMSG_AUTH_AUTHORIZED,		"RSMSG_AUTH_AUTHORIZED" },
	{ RSMSG_CLIENT_INFORMATION,	 "RSMSG_CLIENT_INFORMATION" },
	{ RCMSG_CLIENT_INFORMATION,	 "RCMSG_CLIENT_INFORMATION" },
	{ RSMSG_CLIENT_CLOSE_SESSION,   "RSMSG_CLIENT_CLOSE_SESSION" },
	{ RSMSG_PING,				   "RSMSG_PING" },
	{ RCMSG_PONG,				   "RCMSG_PONG" },
};
	*/
