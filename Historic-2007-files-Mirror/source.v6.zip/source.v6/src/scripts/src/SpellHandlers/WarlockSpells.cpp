#include "StdAfx.h"
#include "Setup.h"

void SetupWarlockSpells(ScriptMgr * mgr)
{
    // moo?
}