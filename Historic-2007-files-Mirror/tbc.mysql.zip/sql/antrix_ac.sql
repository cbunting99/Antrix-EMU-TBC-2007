﻿/*
SQLyog Community Edition- MySQL GUI v6.0
Host - 5.0.41-community-nt : Database - antrix_ac
*********************************************************************
Server version : 5.0.41-community-nt
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `accounts` */

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `acct` int(30) NOT NULL auto_increment,
  `login` varchar(50) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `gm` varchar(50) NOT NULL default '',
  `flags` int(30) NOT NULL default '8',
  `banned` int(30) NOT NULL default '0',
  `lastlogin` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `lastip` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`acct`,`login`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `accounts` */

insert  into `accounts`(`acct`,`login`,`password`,`email`,`gm`,`flags`,`banned`,`lastlogin`,`lastip`) values (1,'test','test','test@test.com','',8,0,'2007-06-07 12:13:56','127.0.0.1');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
